#include <bits/stdc++.h>

using namespace std;

int a[100001];
bool b[100001];

int main()
{
    int T, n, m, r;
    bool flag1 = true, flag2 = true;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        flag1 = true, flag2 = true;
        cin >> n >> m;
        for (int j = 1; j <= n; j++) {
            cin >> a[j];
        }
        for (int j = 1; j <= n; j++) {
            cin >> b[j];
            if (b[j] == 1) {
                if (flag2) {
                    flag2 = false;
                    r = a[j];
                }
                if (flag1 && (a[j] != r)) {
                    flag1 = false;
                }
            } else {
                if (flag1 && a[j] == r) {
                    flag1 = false;
                }
            }
        }
        if (flag2) {
            cout << ">-<" << endl;
        } else if (flag1) {
            cout << r << endl;
        } else {
            cout << "^v^" << endl;
        }
    }
    return 0;
}