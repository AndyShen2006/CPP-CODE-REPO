#include <bits/stdc++.h>

using namespace std;

int main()
{
    int T, n;
    string tin, t;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        t.clear();
        cin >> n >> tin;
        //  Full Expand
        for (int j = 0; j < tin.size(); j++) {
            if (tin[j] == 'w') {
                t.push_back('u');
                t.push_back('u');
            } else if (tin[j] == 'm') {
                t.push_back('n');
                t.push_back('n');
            } else {
                t.push_back(tin[j]);
            }
        }
        //  Output
        int sub = t.size() - n;
        for (int j = 0; j < t.size(); j++) {
            if (t[j] == 'n' && t[j + 1] == 'n' && sub > 0) {
                cout << 'm';
                j++;
                sub--;
            } else if (t[j] == 'u' && t[j + 1] == 'u' && sub > 0) {
                cout << "w";
                j++;
                sub--;
            } else {
                cout << t[j];
            }
        }
        cout << endl;
    }
    return 0;
}
/*
3
5
abcw
7
xuwuxnmnx
3
wm
*/