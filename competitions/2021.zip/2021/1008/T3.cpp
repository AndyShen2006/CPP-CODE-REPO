#include <bits/stdc++.h>

using namespace std;

int main()
{
    cout << "No" << endl;
    return 0;
}