#include <bits/stdc++.h>

using namespace std;

constexpr long long MOD = 1e9 + 7;

long long quickpow(long long a, long long n)
{
    if (n == 0) {
        return 1;
    }
    long long res = quickpow(a * a % MOD, n >> 1);
    if (n & 1) {
        res = res * a % MOD;
    }
    return res;
}
int main()
{
    long long n;
    cin >> n;
    cout << ((quickpow(3, n + 1) - 1) * 500000004) % MOD << endl;
    return 0;
}