#include <bits/stdc++.h>
using namespace std;
const int N = 2e5 + 10;
int nPreMon[N], nPreDi[N], preMon[N], preDi[N], data[N];
int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> data[i];
    }
    for (int i = 1; i <= n; i++) {
        if (i & 1) {
            nPreMon[i] = nPreMon[i - 1] + data[i], preMon[i] = preMon[i - 1];
        } else {
            nPreMon[i] = nPreMon[i - 1], preMon[i] = preMon[i - 1] + data[i];
        }
    }
    for (int i = n; i >= 1; i--) {
        if (i & 1) {
            nPreDi[i] = nPreDi[i + 1] + data[i], preDi[i] = preDi[i + 1];
        } else {
            nPreDi[i] = nPreDi[i + 1], preDi[i] = preDi[i + 1] + data[i];
        }
    }
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        int l, r;
        l = nPreMon[i - 1] + preDi[i + 1];
        r = preMon[i - 1] + nPreDi[i + 1];
        if (l == r)
            ans++;
    }
    cout << ans << endl;
}