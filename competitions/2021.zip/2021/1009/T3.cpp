#include <bits/stdc++.h>

using namespace std;

int main()
{
    int l, r, a, b;
    cin >> l >> r;
    for (int i = r / 2; i >= 1; i--) {
        if (l % i == 0) {
            a = l / i;
        } else {
            a = l / i + 1;
        }
        b = r / i;
        if (b > a) {
            cout << i << endl;
            exit(0);
        }
    }
    return 0;
}