#include <bits/stdc++.h>

using namespace std;

#define MAX_N 100001
#define HIGH true
#define LOW false
#define INF (1e9 + 1)

int a[MAX_N];
int b[MAX_N];
int dp[MAX_N];

int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        b[i] = a[i];
    }
    // Low High Low...
    bool sign = HIGH;
    for (int i = 2; i <= n; i++) {
        if (sign == HIGH) {
            if (b[i] > b[i - 1]) {
                dp[i] = dp[i - 1];
            } else {
                dp[i] = dp[i - 1] + 1;
                b[i] = INF;
            }
            sign = LOW;
        } else {
            if (b[i] < b[i - 1]) {
                dp[i] = dp[i - 1];
            } else {
                dp[i] = dp[i - 1] + 1;
                b[i] = -INF;
            }
            sign = HIGH;
        }
    }
    int ans = dp[n];
    for (int i = 1; i <= n; i++) {
        b[i] = a[i];
    }
    // High Low High...
    sign = LOW;
    for (int i = 2; i <= n; i++) {
        if (sign == HIGH) {
            if (b[i] > b[i - 1]) {
                dp[i] = dp[i - 1];
            } else {
                dp[i] = dp[i - 1] + 1;
                b[i] = INF;
            }
            sign = LOW;
        } else {
            if (b[i] < b[i - 1]) {
                dp[i] = dp[i - 1];
            } else {
                dp[i] = dp[i - 1] + 1;
                b[i] = -INF;
            }
            sign = HIGH;
        }
    }
    ans = min(ans, dp[n]);
    cout << ans << endl;
    return 0;
}