#include <bits/stdc++.h>

using namespace std;

int a[100001];
int b[100001];

int main()
{
    int n, m, sum;
    cin >> n >> m;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    sum = b[0] = a[n - 1] ^ a[0];
    for (int i = 1; i < n; i++) {
        b[i] = a[i] ^ a[i - 1];
        sum += b[i];
    }
    int pos = 0;
    int move;
    cout << sum - b[pos] << ' ';
    for (int i = 0; i < m; i++) {
        cin >> move;
        if (pos - move < 0) {
            pos = (n + pos - move) % n;
        } else {
            pos = (pos - move) % n;
        }
        cout << sum - b[pos] << ' ';
    }
    return 0;
}
/*
5 3
1 2 3 4 5
1 1 2

5 5
10 13 2 5 6
4
1
5
1
2
*/