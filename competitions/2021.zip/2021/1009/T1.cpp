#include <bits/stdc++.h>

using namespace std;

int main()
{
    char c;
    bool type = false;
    c = getchar();
    if (c - '0' == 0) {
        type = true;
    }
    putchar(c);
    while ((c = getchar()) != '\n') {
        if (type) {
            putchar(c);
        } else {
            putchar(!(c - '0') + '0');
        }
    }
    putchar('\n');
    return 0;
}
/*
10011101
*/