#include <bits/stdc++.h>

using namespace std;

int main()
{
    int l, r, q = 0, aq;
    cin >> l >> r;
    int len = r - l + 1;
    for (int i = r; i >= l; i--) {
        for (int p = r / len; p <= i; p++) {
            if (i % p == 0) {
                aq = i / p;
                if (aq <= i - l) {
                    q = max(q, aq);
                    break;
                }
            }
        }
    }
    cout << q << endl;
    return 0;
}