#include <stdio.h>

int main()
{
    //freopen("data/offer1.in", "r", stdin);
    int T, cntA = 0, cntB = 0, cntC = 0, cntD = 0;
    scanf("%d", &T);
    getchar();
    char offer[4];
    while (T--) {
        for (int i = 0; i < 4; i++) {
            offer[i] = getchar();
        }
        getchar();
        cntA = cntB = cntC = cntD = 0;
        for (int i = 0; i < 4; i++) {
            switch (offer[i]) {
            case 'A':
                cntA++;
                break;
            case 'B':
                cntB++;
                break;
            case 'C':
                cntC++;
                break;
            case 'D':
                cntD++;
                break;
            default:
                break;
            }
        }
        if (cntD >= 1 || cntC >= 2) {
            printf("failed\n");
        } else if (cntA >= 3) {
            printf("sp offer\n");
        } else {
            printf("offer\n");
        }
    }
    return 0;
}