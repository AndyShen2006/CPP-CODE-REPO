#include <bits/stdc++.h>
#include <unistd.h>

using namespace std;

vector<int> ans;
bool check[1000001];

int main()
{
    srand(time(0));
    int t = rand() % 10;
    cout << t << endl;
    for (int i = 1; i <= t; i++) {
        int n = rand() % 100000;
        cout << n << endl;
        for (int j = 1; j <= n; j++) {
            int a = rand() % 1000000;
            if (check[a]) {
                j--;
                continue;
            } else {
                ans.push_back(a);
                check[a] = true;
            }
        }
        sort(ans.begin(), ans.end());
        for (int j = 0; j < n; j++) {
            cout << ans[j] << ' ';
        }
        cout << endl;
    }
    sleep(1);
    return 0;
}