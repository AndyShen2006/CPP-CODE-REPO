#include <stdio.h>

int main()
{
    int a, b;
    scanf("%d%d", &a, &b);
    if (a > b) {
        if (b == 0) {
            printf("1\n");
        } else {
            printf("%d\n", b - 1);
        }
    } else {
        if (b == 15) {
            printf("14\n");
        } else {
            printf("%d\n", b + 1);
        }
    }
    return 0;
}