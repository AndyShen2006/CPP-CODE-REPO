#include <bits/stdc++.h>

using namespace std;

int a[1000001];
bool check[1000001];

int main()
{
    //freopen("data/B/B-6.in", "r", stdin);
    //freopen("data/B/B-6.out", "w", stdout);
    int t, n;
    int ans;
    bool flag;
    a[0] = -1;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n;
        flag = false;
        memset(check, 0, sizeof(check));
        for (int j = 1; j <= n; j++) {
            cin >> a[j];
            check[a[j]] = true;
            if (a[j] == a[j - 1]) {
                flag = true;
            }
        }
        if (flag) {
            cout << "-1" << endl;
            continue;
        }
        ans = a[2] - a[1];
        for (int j = 2; j < n; j++) {
            ans = __gcd(ans, a[j + 1] - a[j]);
        }
        // for (int j = a[1]; j <= a[n]; j += ans) {
        //     if (check[j]) {
        //         continue;
        //     } else {
        //         cout << j << ' ';
        //     }
        // }
        // cout << endl;
        cout << (a[n] - a[1]) / ans - n + 1 << endl;
    }
    return 0;
}
/*
2
7
2 4 7 8 9 10 13
8
2 4 6 8 10 12 14 18
*/