#include <stdio.h>

int a[1000001];

int main()
{
    freopen("data/Brandom1.in", "r", stdin);
    int n, X;
    scanf("%d %d", &n, &X);
    for (int i = 1; i <= n; i++) {
        scanf("%d", a + i);
    }
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            ans += ((a[i] ^ a[j]) == X) ? 1 : 0;
        }
    }
    printf("%d\n", ans);
    return 0;
}