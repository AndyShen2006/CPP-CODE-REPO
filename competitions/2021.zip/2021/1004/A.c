#include <stdio.h>

int judge[6010];
int data[6010];

int main()
{
    //freopen("data/A1.in", "r", stdin);
    for (int i = 1; i <= 570; i++) {
        judge[7 + 10 * i] = 1;
    }
    for (int j = 0; j <= 9; j++) {
        for (int k = 0; k <= 57; k++) {
            judge[70 + j + 100 * k] = 1;
        }
    }
    for (int j = 0; j <= 99; j++) {
        for (int k = 0; k <= 5; k++) {
            judge[700 + j + 1000 * k] = 1;
        }
    }
    for (int i = 1; 7 * i <= 5700; i++) {
        judge[7 * i] = 1;
    }
    int last = 1;
    for (int i = 0; i <= 5700; i++) {
        if (judge[i]) {
            data[last++] = i;
        }
    }
    /*
    printf("%d\n", last);
    for (int i = 0; i <= 15; i++) {
        printf("%d ", data[i]);
    }*/
    int t, k;
    scanf("%d", &t);
    for (int i = 1; i <= t; i++) {
        scanf("%d", &k);
        printf("%d\n", data[k]);
    }
    //printf("%d %d %d %d %d\n", data[1007], data[870], data[700], data[15], data[49]);
    return 0;
}