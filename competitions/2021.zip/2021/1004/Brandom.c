#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    //freopen("data/Brandom10.in", "w", stdout);
    srand(time(0));
    int n = rand() % 1000000;
    int k = rand() % (2 << 30);
    printf("%d %d\n", n, k);
    for (int i = 1; i <= n; i++) {
        printf("%d ", rand() % (2 << 30));
    }
    return 0;
}