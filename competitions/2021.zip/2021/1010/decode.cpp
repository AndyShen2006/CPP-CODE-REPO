#include <bits/stdc++.h>
using namespace std;
map<char, char> M;

int main()
{
    string s;
    getline(cin, s);
    char c;
    for (int i = 0; i < 26; i++) {
        cin >> c;
        M['A' + i] = c;
    }
    for (int i = 0; i < s.size(); i++) {
        if (isupper(s[i])) {
            cout << M[s[i]];
        } else {
            cout << s[i];
        }
    }
    cout << endl;
    return 0;
}