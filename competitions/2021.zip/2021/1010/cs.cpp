#include <bits/stdc++.h>

using namespace std;

int a[201], b[201], c[201];
int n;

int dfs(int level, int aCnt, int bCnt)
{
    if (level > n) {
        return max(aCnt, bCnt);
    } else {
        /*
        int x = dfs(level + 1, aCnt + a[level], bCnt);
        int y = dfs(level + 1, aCnt, bCnt + b[level]);
        if (x < y) {
            c[level] = a[level];
            return x;
        } else {
            c[level] = b[level];
            return y;
        }
        */
        return min(dfs(level + 1, aCnt + a[level], bCnt), dfs(level + 1, aCnt, bCnt + b[level]));
    }
}

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i] >> b[i];
    }
    cout << dfs(1, 0, 0) << endl;
    for (int i = 1; i <= n; i++) {
        printf("%d %d->%d\n", a[i], b[i], c[i]);
    }
    return 0;
}
/*
7
5 10
6 11
7 12
17 8
9 28
15 20
20 13
*/