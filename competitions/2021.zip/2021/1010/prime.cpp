#include <bits/stdc++.h>

using namespace std;

bool isPrime[1000005];

int main()
{
    isPrime[0] = isPrime[1] = true;
    for (int i = 2; i <= 1000005; i++) {
        if (!isPrime[i]) {
            for (int j = i + i; j <= 1000005; j += i) {
                isPrime[j] = true;
            }
        }
    }
    int a, b;
    cin >> a >> b;
    int cnt = 0;
    for (int i = a; i <= b; i++) {
        if (!isPrime[i]) {
            cnt++;
        }
    }
    cout << cnt << endl;
    return 0;
}