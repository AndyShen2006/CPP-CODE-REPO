#include <bits/stdc++.h>

using namespace std;

int book[100001];
int n, m;

bool check(int mid)
{
    int now = 0, cnt = 0;
    for (int i = 1; i <= n; i++) {
        if (now + book[i] <= mid) {
            now += book[i];
        } else {
            now = book[i];
            cnt++;
        }
    }
    return cnt >= m;
}

int main()
{
    int l = 0, r = 0, mid;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        cin >> book[i];
        l = max(l, book[i]);
        r += book[i];
    }
    while (l <= r) {
        mid = (l + r) >> 1;
        //printf("%d %d %d\n", l, mid, r);
        if (check(mid)) {
            l = mid + 1;
        } else {
            r = mid - 1;
        }
    }
    cout << l << endl;
    return 0;
}
/*
5 3
3
2
4
1
5
*/