#include <bits/stdc++.h>

using namespace std;

pair<int, int> cnt[100];

int main()
{
    int n;
    char c;
    cin >> n;
    getchar();
    for (int i = 1; i <= n; i++) {
        cnt[i].second = i;
        cnt[i].first = 0;
        for (int j = 1; j <= n; j++) {
            c = getchar();
            switch (c) {
            case 'W':

                cnt[i].first += 2;
                break;
            case 'D':
                cnt[i].first += 1;
                break;
            default:
                break;
            }
        }
        getchar();
    }
    sort(cnt + 1, cnt + n + 1, greater<pair<int, int>>());
    int now = cnt[1].first;
    for (int i = n; i >= 1; i--) {
        if (cnt[i].first == now)
            cout << cnt[i].second << ' ';
    }
    cout << endl;
    return 0;
}