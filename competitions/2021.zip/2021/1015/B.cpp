#include <bits/stdc++.h>
using namespace std;

long long a[1000001];

int main()
{
    long long n, sum = 0;
    cin >> n;
    for (long long i = 1; i <= n; i++) {
        cin >> a[i];
        sum += a[i];
        a[i] = -a[i];
    }
    long long tempSum = 0;
    long long maxSum = 0;
    for (long long j = 1; j <= n; j++) // 子问题后边界
    {
        tempSum = max(tempSum + a[j], a[j]);
        maxSum = max(tempSum, maxSum);
    }
    cout << sum + maxSum << endl;
    return 0;
}