#include <stdio.h>

int a[100001];
// A stack to store ans which is already completed
int stack[100001];
int* top = stack;

int main()
{
    int n, ansWindow1 = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", a + i);
        // For window 1
        ansWindow1 += *(a + i) * *(a + i);
    }
    printf("%d ", ansWindow1);
    // For window 2 to n
    int* l = a;
    int ans = 0;
    while (l < a + n - 1) {
        ans += *l * *(l + 1);
        //push into stack
        *top = ans;
        top++;
        l++;
    }
    top--;
    while (top != stack) {
        printf("%d ", *top);
        top--;
    }
    printf("%d ", *top);
    putchar('\n');
    return 0;
}