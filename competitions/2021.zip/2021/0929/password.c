#include <ctype.h>
#include <stdio.h>

int ans = 0;
char p1[10001];
char* l = p1;
char p2[10001];
char* u = p2;
char p3[10001];
char* n = p3;
char p4[10001];
char* o = p4;

int main()
{
    char c;
    while ((c = getchar()) != '\n') {
        if (islower(c)) {
            *l = c;
            l++;
            continue;
        } else if (isupper(c)) {
            *u = c;
            u++;
            continue;
        } else if (isdigit(c)) {
            *n = c;
            n++;
            continue;
        } else {
            *o = c;
            o++;
            continue;
        }
    }
    if (l != p1) {
        ans++;
    }
    if (u != p2) {
        ans++;
    }
    if (n != p3) {
        ans++;
    }
    if (o != p4) {
        ans++;
    }
    printf("password level:%d\n", ans);
    if (l != p1) {
        printf("%s", p1);
    } else {
        printf("(Null)");
    }
    putchar('\n');
    if (u != p2) {
        printf("%s", p2);
    } else {
        printf("(Null)");
    }
    putchar('\n');
    if (n != p3) {
        printf("%s", p3);
    } else {
        printf("(Null)");
    }
    putchar('\n');
    if (o != p4) {
        printf("%s", p4);
    } else {
        printf("(Null)");
    }
    putchar('\n');
    return 0;
}