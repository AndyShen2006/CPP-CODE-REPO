#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

int main()
{
    ll n, x, y, a, b, ans;
    cin >> n >> x >> y;
    if (x == 1) {
        cout << y - 1 << endl;
    } else {
        if (x & 1) {
            a = ((x - 1) % 10) * (n % 10);
            b = x - 1;
            b /= 2;
            b = (b % 10) * ((x - 2) % 10);
            ans = a + b - 1;
            if (ans < 0) {
                cout << (ans + 10 + y) % 10;
            } else {
                cout << (ans + y) % 10;
            }
        } else {
            a = ((x - 1) % 10) * (n % 10);
            b = x - 2;
            b /= 2;
            b = (b % 10) * ((x - 1) % 10);
            ans = a + b - 1;
            if (ans < 0) {
                cout << (ans + 10 + y) % 10;
            } else {
                cout << (ans + y) % 10;
            }
        }
    }
    return 0;
}