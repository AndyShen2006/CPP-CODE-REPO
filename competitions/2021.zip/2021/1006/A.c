#include <stdio.h>

int main()
{
    long long aMin = 0x3f3f3f3f3f3f3f3f, bMin = 0x3f3f3f3f3f3f3f3f;
    long long ta, tb;
    scanf("%lld", &ta);
    aMin = ta < aMin ? ta : aMin;
    scanf("%lld", &ta);
    aMin = ta < aMin ? ta : aMin;
    scanf("%lld", &ta);
    aMin = ta < aMin ? ta : aMin;
    scanf("%lld", &ta);
    aMin = ta < aMin ? ta : aMin;
    scanf("%lld", &tb);
    bMin = tb < bMin ? tb : bMin;
    scanf("%lld", &tb);
    bMin = tb < bMin ? tb : bMin;
    scanf("%lld", &tb);
    bMin = tb < bMin ? tb : bMin;
    printf("%lld\n", aMin + bMin);
    return 0;
}