#include <bits/stdc++.h>

using namespace std;

int a[1001][1001];

int main()
{
    int n, m, q;
    cin >> n >> m >> q;
    int o, p, d;
    for (int i = 1; i <= q; i++) {
        cin >> o >> p >> d;
        switch (o) {
        case 1:
            for (int j = 1; j <= m; j++) {
                a[p][j] = d;
            }
            break;
        case 2:
            for (int j = 1; j <= n; j++) {
                a[j][p] = d;
            }
            break;
        default:
            break;
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cout << a[i][j] << ' ';
        }
        cout << endl;
    }
    return 0;
}