#include <bits/stdc++.h>

using namespace std;

int a[1000001];
bool q[1000001];

int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    int m = 0;
    for (int i = n; i >= 1; i--) {
        if (a[i] >= m) {
            m = a[i];
        } else {
            if (!q[a[i]]) {
                cout << 1 << endl;
                return 0;
            }
        }
        q[a[i]] = true;
    }
    cout << 0 << endl;
    return 0;
}
/*
4
4 1 3 2
*/