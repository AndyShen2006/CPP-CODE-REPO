#include <bits/stdc++.h>

using namespace std;
typedef pair<int, int> P;
vector<P> lands; //First->m,Second->k
int main()
{
    int n, k;
    int tk, tm;
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> tk >> tm;
        if (tk < tm) {
            continue;
        } else {
            lands.push_back(P(tm, tk));
        }
    }
    sort(lands.begin(), lands.end());
    for (int i = 0; i < lands.size(); i++) {
        if (k > lands[i].first) { //Is valid
            k += lands[i].second - lands[i].first; //Take it
        }
    }
    cout << k << endl;
    return 0;
}