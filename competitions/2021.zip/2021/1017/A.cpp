#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n, t;
    cin >> n >> t;
    cout << (t / n) % n + 1 << ' ' << t % n + 1 << endl;
    return 0;
}