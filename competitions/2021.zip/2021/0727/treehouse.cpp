#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("treehouse.in", "r", stdin);
    freopen("treehouse.out", "w", stdout);
    cout << "No solution." << endl;
    return 0;
}