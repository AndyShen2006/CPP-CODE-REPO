#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    freopen("D/D1.in", "w", stdout);
    srand(time(0));
    int B = rand() % 10 + 1;
    printf("%d\n", B);
    for (int i = 1; i <= B; i++) {
        int start, si;
        start = rand() % B;
        si = rand() % (B - start) + 1;
        printf("%d %d\n", start, start + si);
    }
    return 0;
}