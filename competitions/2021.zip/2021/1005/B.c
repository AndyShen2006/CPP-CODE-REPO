#include <stdio.h>

long long a[31][31];

int main()
{
    for (long long i = 1; i <= 30; i++) {
        a[i][1] = a[1][i] = i + 1;
    }
    for (long long i = 2; i <= 30; i++) {
        for (long long j = 2; j <= 30; j++) {
            a[i][j] = a[i - 1][j] + a[i][j - 1];
        }
    }
    long long n, m;
    scanf("%lld%lld", &n, &m);
    printf("%lld", a[n][m]);
    return 0;
}