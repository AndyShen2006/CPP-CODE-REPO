#include <iostream>
#include <string>
using namespace std;

int main()
{
    string ans = "CDABACBDDCACBCB";
    cout << ans << endl;
    return 0;
}