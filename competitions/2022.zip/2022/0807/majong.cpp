#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin >> t;
    int a1, a2, a3, a4;
    bool sign;
    bool isAppear[20];
    for (int i = 1; i <= t; i++) {
        memset(isAppear, 0, sizeof(isAppear));
        sign = false;
        cin >> a1 >> a2 >> a3 >> a4;
    }
    return 0;
}