g++ gcd-dg.cpp -o gcd-dg -Wall -O2 -lext_random -lbasic_lib
g++ ex-dg.cpp -o ex-dg -Wall -O2 -lext_random -lbasic_lib