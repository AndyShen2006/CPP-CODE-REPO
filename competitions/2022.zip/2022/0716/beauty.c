#include <math.h>
#include <stdio.h>

int main()
{
    double z;
    scanf("%lf", &z);
    printf("%.2f", sqrt(z) * sqrt(2));
    return 0;
}