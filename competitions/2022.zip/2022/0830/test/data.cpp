#include <ext_random.hpp>

using namespace std;

int main()
{
    int n = randint(1, 10000);
    cout << n << endl;
    for (int i = 1; i <= n; i++) {
        cout << randll(1000000000, 100000000000) << ' ' << randll(1000000000, 100000000000) << ' ' << randll(1000, 100000) << endl;
    }
    return 0;
}