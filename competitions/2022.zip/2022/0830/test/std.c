#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    int i;
    long long a, b, c;
    long long ans = 0;
    for (i = 1; i <= n; i++) {
        scanf("%lld%lld%lld", &a, &b, &c);
        ans += (a - b) * c;
    }
    printf("%lld", ans);
    return 0;
}