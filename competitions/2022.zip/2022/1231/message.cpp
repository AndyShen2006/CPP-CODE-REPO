#include <bits/stdc++.h>

using namespace std;

constexpr int MAX_N = 1000010;
bool f[MAX_N];
vector<int> mes;

int main()
{
    int n, m;
    cin >> n >> m;
    string tf;
    cin >> tf;
    for (int i = 0; i < tf.size(); i++) {
        f[i + 1] = tf[i] - '0';
    }
    int tmp;
    for (int i = 1; i <= n; i++) {
        cin >> tmp;
        mes.emplace_back(tmp);
    }
    int ans = 0;
    for (int i = 0; i < n; i++) {
        if (f[mes[i] - ans] == 1) {
            ans++;
        }
    }
    cout << ans << endl;
    return 0;
}