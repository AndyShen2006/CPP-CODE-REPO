#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n;
    cin >> n;
    if (n % 2 == 1) {
        cout << -1 << endl;
        exit(0);
    } else {
        for (int i = 2; i <= n; i++) {
            cout << 1 << ' ' << i << endl;
        }
    }
    return 0;
}