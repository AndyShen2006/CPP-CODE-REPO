#include <bits/stdc++.h>

using namespace std;

int main()
{
    // freopen("data/jump1.in", "r", stdin);
    int t;
    cin >> t;
    int k;
    for (int i = 1; i <= t; i++) {
        cin >> k;
        if (k % 2 == 0) {
            cout << -1 << endl;
            continue;
        }
        cout << static_cast<int>(log2(k) + 1) << endl;
    }
    return 0;
}