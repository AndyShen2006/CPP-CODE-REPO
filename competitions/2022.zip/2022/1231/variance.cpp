#include <bits/stdc++.h>

using namespace std;

typedef __int128 ell;
typedef long long ll;

inline void read(ell& x)
{
    char ch;
    x = 0ull;
    do
        ch = static_cast<char>(getchar());
    while (isspace(ch));
    while (isdigit(ch)) {
        x *= 10ull;
        x += ch;
        x -= '0';
        ch = static_cast<char>(getchar());
    }
}

inline void read(ll& x)
{
    char ch;
    x = 0ull;
    do
        ch = static_cast<char>(getchar());
    while (isspace(ch));
    while (isdigit(ch)) {
        x *= 10ull;
        x += ch;
        x -= '0';
        ch = static_cast<char>(getchar());
    }
}

void print(ell x)
{
    if (x < 0) {
        putchar('-');
        x = -x;
    }
    if (x < 10) {
        putchar(static_cast<int>(x + 48));
        return;
    }
    print(x / 10);
    putchar(static_cast<int>(x % 10 + 48));
}

ll a[1000010], b[1000010];

int main()
{
    ll n;
    read(n);
    for (int i = 1; i <= n; i++) {
        read(a[i]);
    }
    for (int i = 1; i <= n; i++) {
        read(b[i]);
    }
    ell sqsum = 0, sum = 0;
    for (int i = 1; i <= n; i++) {
        sqsum += b[i] * b[i];
        sum += b[i];
    }
    ell ans = sqsum * n - sum * sum;
    for (int i = 1; i <= n; i++) { //前i个取最小
        sqsum = sqsum - b[i] * b[i] + a[i] * a[i];
        sum = sum - b[i] + a[i];
        ans = max(ans, sqsum * n - sum * sum);
    }
    print(ans);
    return 0;
}