#include <bits/stdc++.h>

using namespace std;

int dp[3010][2];
int pos[3010];

int main()
{
    int n, m, a, b;
    cin >> n >> m >> a >> b;
    for (int i = 1; i <= m; i++) {
        cin >> pos[i];
    }

    return 0;
}