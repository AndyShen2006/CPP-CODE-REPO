#include <bits/stdc++.h>

using namespace std;

vector<int> G[100010];

int main()
{
    int n, m;
    return 0;
}