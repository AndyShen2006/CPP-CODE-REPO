g++ makedata.cpp -o makedata -lext_random -lbasic_lib
g++ maimai.cpp -o maimai -O2