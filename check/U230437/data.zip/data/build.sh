g++ makedata.cpp -o makedata -Wall -O2 -lext_random -lbasic_lib
g++ makedata11-14.cpp -o makedata2 -Wall -O2 -lext_random -lbasic_lib
g++ std.cpp -o march -Wall -O2