g++ makedata.cpp -o makedata -lext_random -lbasic_lib
g++ std2.cpp -o newjney -O2