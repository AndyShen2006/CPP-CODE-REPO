#include<bits/stdc++.h>

using namespace std;

int main()
{
	int a,b,c,ans;
	cin >> a >> b >> c;
	ans=0.2*a+0.3*b+0.5*c;
	cout << ans;
	return 0;
}

